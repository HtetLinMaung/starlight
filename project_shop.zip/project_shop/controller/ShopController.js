$(document).ready(() => {

    showCount();

    $('.add').click(function () {
        let id = $(this).data('id');
        let price = $(this).data('price');
        let name = $(this).data('name');
        let photo = $(this).data('photo');

        let item = {
            id: id,
            price: price,
            name: name,
            photo: photo,
            type: $(this).data('type'),
            quantity: 1
        };

        let mycartobj = getList('mycart');

        let status = false;

        $.each(mycartobj.itemlist, function (i, v) {
            if (v.id == id) {
                status = true;
                v.quantity++;
            }
        });

        if (!status) {
            mycartobj.itemlist.push(item);
        }

        save('mycart', mycartobj);
        showCount();
    });

    // Functions
    function showCount() {
        let mycartobj = getList('mycart', 'itemlist');
        let total = 0;

        $.each(mycartobj.itemlist, function (i, v) {
            total += parseInt(v.quantity);
        });
        $('#showcount').html(`Cart<small class="text-warning">${total}</small>`);
    }
});