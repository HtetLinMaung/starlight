$(document).ready(() => {
    let html = '';
    const style = ['table-primary', 'table-secondary', 'table-success', 'table-danger', 'table-warning', 'table-info'];
    let i = 0;
    let total = 0;
    let mycartobj = getList('mycart', 'itemlist');
    let myrecordobj = getList('myrecord', 'salelist');
    let salecount = {
        bag: 0,
        watch: 0,
        Apple: 0,
        total: 0
    };

    if (mycartobj.itemlist.length != 0) {
        for (const item of mycartobj.itemlist) {
            total += item.quantity;
        }
        $('small').html(`${total}`);
    }


    if (myrecordobj.salelist.length != 0) {
        for (const sale of myrecordobj.salelist) {
            if (i == style.length) i = 0;
            html += `
                <tr class="${style[i++]}">
                    <td>${sale.id}</td>
                    <td>${sale.quantity}</td>
                    <td>${sale.time}</td>
                </tr>
            `;

            $('tbody').html(html);

            salecount.total += sale.quantity;
            salecount[sale.type] += sale.quantity;
        }

        let per = {
            bag: (salecount.bag / salecount.total) * 100,
            watch: (salecount.watch / salecount.total) * 100,
            Apple: (salecount.Apple / salecount.total) * 100
        };

        plot([per.bag, per.watch, per.Apple],
             ['bag', 'watch', 'Apple']);
    } else {
        $('.record table').hide();
        $('#chart').hide();
        $('.record h1').html('Sorry, no item has been sale :(');
    }

    function plot(percentages, labels) {
        const data = [{
            values: percentages,
            labels: labels,
            type: 'pie'
        }];

        Plotly.newPlot('chart', data, {}, { showSendToCloud: true });
    }
});