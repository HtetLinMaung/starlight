$(document).ready(function () {

    displayUI();

    $('tbody').on('click', '.btndelete', function () {
        let id = $(this).data('id');
        if (confirm('Are you sure?')) {
            removeItem(id);
        }
    });

    $('tbody').on('click', '.btnincrease', function () {
        let id = $(this).data('id');
        increaseItem(id);
    });

    $('tbody').on('click', '.btndecrease', function () {
        let id = $(this).data('id');
        decreaseItem(id);
    });

    $('tbody').on('click', '.btncheckout', function () {
        checkOut();
    });

    // Functions
    function displayUI() {
        let total = 0;
        let mycartobj = getList('mycart', 'itemlist')

        if (mycartobj.itemlist.length != 0) {
            
            let html = '';
            let totalPrice = 0;
            let j = 1;


            $.each(mycartobj.itemlist, function (i, v) {
                let id = v.id;
                let name = v.name;
                let photo = v.photo;
                let price = v.price;
                let quantity = v.quantity;
                let subtotal = quantity * price;

                totalPrice += parseInt(subtotal);

                total += parseInt(v.quantity);

                html += `
                    <tr>
                        <td>${j++}</td>
                        <td>
                            <img src="${photo}" width=200 height=150>
                        </td>
                        <td>${name}</td>
                        <td>${price}</td>
                        <td>
                            <button class="btnincrease btn btn-success" data-id="${id}">
                                +
                            </button>
                            ${quantity}
                            <button class="btndecrease btn btn-warning" data-id="${id}">
                                -
                            </button>
                        </td>
                        <td>${subtotal}</td>
                        <td>
                            <button class="btndelete btn btn-danger" data-id="${id}">
                                Delete
                            </button>
                        </td>
                    </tr>
                `;

                $('#showcount').html(`Cart<small class="text-warning">${total}</small>`);
                $('#totalitem').html(`Total items ${total}`)
            });

            html += `
                <tr>
                    <td colspan=6 class="text-right">
                        TOTAL KS:
                    </td>
                    <td>
                        ${totalPrice} KS
                    </td>
                </tr>
                <tr>
                    <td colspan="5"></td>
                    <td colspan="2">
                        <button class="btncheckout w-100 btn btn-success">Check Out</button>
                    </td>
                </tr>
            `;

            $('tbody').html(html);
        } else {
            $('#totalitem').html(`Total items ${total}`);
            $('#showcount').html(`Cart<small class="text-warning">${total}</small>`);
            $('div.table').hide();
            $('.empty').html('You have added nothing in the cart!');
        }
    }

    function removeItem(id) {
        // remove single item
        let mycartobj = getList('mycart');

        $.each(mycartobj.itemlist, function (index, item) {
            if (item.id == id) {
                mycartobj.itemlist.splice(index, 1);
                return false; // break out of jquery foreach
            }
        });

        save('mycart', mycartobj);
        updateUI();
    }

    function increaseItem(id) {
        // increase quantity
        let mycartobj = getList('mycart');

        for (const item of mycartobj.itemlist) {
            if (item.id == id) {
                item.quantity++;
                save('mycart', mycartobj);
                updateUI();
                break;
            }
        }
    }

    function decreaseItem(id) {
        // decrease quantity
        let mycartobj = getList('mycart');

        for (const item of mycartobj.itemlist) {
            if (item.id == id) {
                if (--item.quantity == 0) {
                    save('mycart', mycartobj);
                    removeItem(item.id);
                    break;
                }
                save('mycart', mycartobj);
                updateUI();
                break;
            }
        }
    }

    function checkOut() {
        let myrecordobj = getList('myrecord', 'salelist');
        let mycartobj = getList('mycart');

        for (const item of mycartobj.itemlist) {
            let list = {
                id: item.id,
                quantity: item.quantity,
                type: item.type,
                time: new Date().toLocaleString()
            };

            console.log(myrecordobj);
            myrecordobj.salelist.push(list);
        }

        save('myrecord', myrecordobj);
        mycartobj.itemlist = []; // empty mycart storage
        save('mycart', mycartobj);
        window.location.href = 'shop.html'; // redirect to shop.html
    }

    function updateUI() {
        $('tbody').empty();
        displayUI();
    }
});