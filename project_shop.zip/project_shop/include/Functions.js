function getList(storageName, storageKey = 'dummyKey') {
    // 
    let data = localStorage.getItem(storageName);

    if (!data) {
        data = `{"${storageKey}": []}`;
        let obj = JSON.parse(data);
        save(storageName, obj);
        return obj;
    }

    let obj = JSON.parse(data);
    return obj;
}

function save(storageName, obj) {
    // 
    localStorage.setItem(storageName, JSON.stringify(obj));
}